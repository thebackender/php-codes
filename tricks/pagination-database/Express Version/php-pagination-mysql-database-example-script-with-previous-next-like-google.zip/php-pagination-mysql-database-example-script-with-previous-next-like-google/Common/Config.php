<?php
namespace Phppot;

class Config
{

    const LIMIT_PER_PAGE = '5';
}
